# Keep VoltReelsOverlay classes
-keep class com.voltreels.fx.** { *; }
