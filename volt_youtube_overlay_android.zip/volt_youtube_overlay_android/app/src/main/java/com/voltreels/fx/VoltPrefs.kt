package com.voltreels.fx

import android.content.Context
import android.graphics.Color

data class AnimeTheme(
    val id: String,
    val title: String,
    val primaryColor: Int,
    val secondaryColor: Int,
    val coreColor: Int
)

object VoltPrefs {
    private const val PREF_NAME = "volt_fx_prefs"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_THEME = "theme_index"
    private const val KEY_INTENSITY = "intensity"
    private const val KEY_BOLTS = "bolts"
    private const val KEY_SPEEDLINES = "speedlines"
    private const val KEY_AURA = "aura"

    val THEMES = listOf(
        AnimeTheme("thunder", "Thunder Breathing", Color.parseColor("#FACC15"), Color.parseColor("#FB923C"), Color.WHITE),
        AnimeTheme("godspeed", "Godspeed Cyan", Color.parseColor("#22D3EE"), Color.parseColor("#38BDF8"), Color.parseColor("#ECFEFF")),
        AnimeTheme("hollow", "Hollow Purple", Color.parseColor("#C084FC"), Color.parseColor("#EC4899"), Color.parseColor("#FAF5FF")),
        AnimeTheme("crimson", "Crimson Flash", Color.parseColor("#F43F5E"), Color.parseColor("#FB923C"), Color.parseColor("#FFF1F2")),
        AnimeTheme("cyber", "Cyber Overdrive", Color.parseColor("#34D399"), Color.parseColor("#2DD4BF"), Color.parseColor("#ECFDF5"))
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    fun isEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_ENABLED, true)
    fun setEnabled(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean(KEY_ENABLED, v).apply()

    fun getThemeIndex(ctx: Context): Int = prefs(ctx).getInt(KEY_THEME, 0).coerceIn(0, THEMES.lastIndex)
    fun setThemeIndex(ctx: Context, idx: Int) = prefs(ctx).edit().putInt(KEY_THEME, idx.coerceIn(0, THEMES.lastIndex)).apply()
    fun getTheme(ctx: Context): AnimeTheme = THEMES[getThemeIndex(ctx)]

    fun getIntensity(ctx: Context): Int = prefs(ctx).getInt(KEY_INTENSITY, 85).coerceIn(20, 100)
    fun setIntensity(ctx: Context, v: Int) = prefs(ctx).edit().putInt(KEY_INTENSITY, v.coerceIn(20, 100)).apply()

    fun isBoltsEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_BOLTS, true)
    fun setBoltsEnabled(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean(KEY_BOLTS, v).apply()

    fun isSpeedlinesEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SPEEDLINES, true)
    fun setSpeedlinesEnabled(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean(KEY_SPEEDLINES, v).apply()

    fun isAuraEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_AURA, true)
    fun setAuraEnabled(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean(KEY_AURA, v).apply()
}
