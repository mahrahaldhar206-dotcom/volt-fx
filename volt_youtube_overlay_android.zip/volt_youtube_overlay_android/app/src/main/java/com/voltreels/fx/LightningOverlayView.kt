package com.voltreels.fx

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.util.AttributeSet
import android.view.View
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class LightningOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private data class Bolt(
        val points: List<PointF>,
        val branch: List<PointF>?,
        var life: Float,
        val decay: Float,
        val strokeWidth: Float,
        val primaryColor: Int,
        val secondaryColor: Int,
        val coreColor: Int
    )

    private data class SpeedLine(
        val x: Float,
        var y: Float,
        val length: Float,
        val vy: Float,
        val width: Float,
        var life: Float,
        val color: Int
    )

    private data class Spark(
        var x: Float,
        var y: Float,
        val vx: Float,
        var vy: Float,
        val radius: Float,
        var life: Float,
        val color: Int
    )

    private val bolts = mutableListOf<Bolt>()
    private val speedLines = mutableListOf<SpeedLine>()
    private val sparks = mutableListOf<Spark>()
    private var auraEnergy = 0f
    private var auraColor = Color.YELLOW

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        maskFilter = BlurMaskFilter(22f, BlurMaskFilter.Blur.NORMAL)
    }

    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val sparkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val auraPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        maskFilter = BlurMaskFilter(45f, BlurMaskFilter.Blur.NORMAL)
    }

    private val reusablePath = Path()

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun triggerBurst(power: Float = 0.95f, direction: Int = 1) {
        if (!VoltPrefs.isEnabled(context)) return
        val w = width.toFloat().coerceAtLeast(360f)
        val h = height.toFloat().coerceAtLeast(720f)
        val theme = VoltPrefs.getTheme(context)
        val mult = VoltPrefs.getIntensity(context) / 80f
        val p = (power * mult).coerceIn(0.3f, 1.45f)

        auraColor = theme.primaryColor
        if (VoltPrefs.isAuraEnabled(context)) {
            auraEnergy = max(auraEnergy, p)
        }

        if (VoltPrefs.isBoltsEnabled(context)) {
            val count = (2 + (p * 4.2f).toInt()).coerceAtMost(8)
            repeat(count) {
                val edgeSpawn = Random.nextFloat() < 0.72f
                val sx = if (edgeSpawn) {
                    if (Random.nextBoolean()) Random.nextFloat() * 64f else w - Random.nextFloat() * 64f
                } else {
                    Random.nextFloat() * w
                }
                val sy = if (direction >= 0) h + 16f else -16f
                val ex = (sx + (Random.nextFloat() - 0.5f) * w * 0.58f).coerceIn(0f, w)
                val ey = if (direction >= 0) Random.nextFloat() * h * 0.45f else h * 0.55f + Random.nextFloat() * h * 0.45f
                val mainPts = buildLightning(sx, sy, ex, ey, 110f + p * 55f, 0)

                val branchPts = if (mainPts.size > 5 && Random.nextFloat() < 0.7f) {
                    val pivot = mainPts[Random.nextInt(2, mainPts.size - 2)]
                    val bx = (pivot.x + (Random.nextFloat() - 0.5f) * 200f).coerceIn(0f, w)
                    val by = pivot.y + (if (direction >= 0) -1f else 1f) * (90f + Random.nextFloat() * 140f)
                    buildLightning(pivot.x, pivot.y, bx, by, 52f, 1)
                } else null

                bolts.add(
                    Bolt(
                        points = mainPts,
                        branch = branchPts,
                        life = 1f,
                        decay = 0.06f + Random.nextFloat() * 0.035f,
                        strokeWidth = 3.5f + Random.nextFloat() * 4.5f * p,
                        primaryColor = theme.primaryColor,
                        secondaryColor = theme.secondaryColor,
                        coreColor = theme.coreColor
                    )
                )
            }

            repeat((10 * p).toInt().coerceAtMost(18)) {
                sparks.add(
                    Spark(
                        x = Random.nextFloat() * w,
                        y = if (direction >= 0) h * (0.3f + Random.nextFloat() * 0.7f) else Random.nextFloat() * h * 0.7f,
                        vx = (Random.nextFloat() - 0.5f) * 12f,
                        vy = (if (direction >= 0) -1f else 1f) * (14f + Random.nextFloat() * 24f),
                        radius = 3f + Random.nextFloat() * 4.5f,
                        life = 1f,
                        color = if (Random.nextBoolean()) theme.primaryColor else theme.coreColor
                    )
                )
            }
        }

        if (VoltPrefs.isSpeedlinesEnabled(context)) {
            val lineCount = (14 + (p * 22f).toInt()).coerceAtMost(42)
            repeat(lineCount) {
                val x = if (Random.nextFloat() < 0.78f) {
                    if (Random.nextBoolean()) Random.nextFloat() * w * 0.24f else w - Random.nextFloat() * w * 0.24f
                } else {
                    Random.nextFloat() * w
                }
                speedLines.add(
                    SpeedLine(
                        x = x,
                        y = Random.nextFloat() * h,
                        length = 120f + Random.nextFloat() * 260f * p,
                        vy = (if (direction >= 0) -1f else 1f) * (42f + Random.nextFloat() * 44f * p),
                        width = 2.5f + Random.nextFloat() * 3.5f,
                        life = 1f,
                        color = if (Random.nextFloat() < 0.35f) Color.WHITE else theme.primaryColor
                    )
                )
            }
        }

        postInvalidateOnAnimation()
    }

    private fun buildLightning(
        x1: Float, y1: Float, x2: Float, y2: Float, displace: Float, depth: Int
    ): List<PointF> {
        if (depth >= 4 || displace < 10f) {
            return listOf(PointF(x1, y1), PointF(x2, y2))
        }
        val midX = (x1 + x2) / 2f + (Random.nextFloat() - 0.5f) * displace
        val midY = (y1 + y2) / 2f + (Random.nextFloat() - 0.5f) * displace * 0.4f
        val left = buildLightning(x1, y1, midX, midY, displace * 0.55f, depth + 1)
        val right = buildLightning(midX, midY, x2, y2, displace * 0.55f, depth + 1)
        return left + right.drop(1)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        var keepAnimating = false

        // 1. Edge Aura Glow
        if (auraEnergy > 0.02f) {
            auraEnergy *= 0.90f
            auraPaint.color = auraColor
            auraPaint.alpha = (min(1f, auraEnergy * 0.75f) * 210).toInt().coerceIn(0, 255)
            auraPaint.strokeWidth = 22f + auraEnergy * 24f
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), auraPaint)
            keepAnimating = true
        }

        // 2. Speedlines
        val lineIter = speedLines.iterator()
        while (lineIter.hasNext()) {
            val l = lineIter.next()
            l.y += l.vy
            l.life -= 0.075f
            if (l.life <= 0f) {
                lineIter.remove()
                continue
            }
            linePaint.color = l.color
            linePaint.alpha = (l.life * 205).toInt().coerceIn(0, 255)
            linePaint.strokeWidth = l.width
            canvas.drawLine(l.x, l.y, l.x, l.y + l.length, linePaint)
            keepAnimating = true
        }

        // 3. Lightning Bolts
        val boltIter = bolts.iterator()
        while (boltIter.hasNext()) {
            val b = boltIter.next()
            b.life -= b.decay
            if (b.life <= 0f) {
                boltIter.remove()
                continue
            }
            drawBolt(canvas, b.points, b.strokeWidth, b.primaryColor, b.coreColor, b.life)
            b.branch?.let {
                drawBolt(canvas, it, b.strokeWidth * 0.6f, b.secondaryColor, b.coreColor, b.life * 0.85f)
            }
            keepAnimating = true
        }

        // 4. Sparks
        val sparkIter = sparks.iterator()
        while (sparkIter.hasNext()) {
            val s = sparkIter.next()
            s.x += s.vx
            s.y += s.vy
            s.vy *= 0.93f
            s.life -= 0.06f
            if (s.life <= 0f) {
                sparkIter.remove()
                continue
            }
            sparkPaint.color = s.color
            sparkPaint.alpha = (s.life * 255).toInt().coerceIn(0, 255)
            canvas.drawCircle(s.x, s.y, s.radius, sparkPaint)
            keepAnimating = true
        }

        if (keepAnimating) {
            postInvalidateOnAnimation()
        }
    }

    private fun drawBolt(
        canvas: Canvas,
        pts: List<PointF>,
        width: Float,
        primary: Int,
        core: Int,
        alpha: Float
    ) {
        if (pts.size < 2) return
        reusablePath.reset()
        reusablePath.moveTo(pts[0].x, pts[0].y)
        for (i in 1 until pts.size) {
            reusablePath.lineTo(pts[i].x, pts[i].y)
        }

        glowPaint.color = primary
        glowPaint.alpha = (alpha * 225).toInt().coerceIn(0, 255)
        glowPaint.strokeWidth = width * 2.4f
        canvas.drawPath(reusablePath, glowPaint)

        corePaint.color = core
        corePaint.alpha = (alpha * 255).toInt().coerceIn(0, 255)
        corePaint.strokeWidth = max(2f, width * 0.72f)
        canvas.drawPath(reusablePath, corePaint)
    }
}
