package com.voltreels.fx

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private lateinit var previewOverlay: LightningOverlayView
    private lateinit var statusBadge: TextView
    private lateinit var themeNameText: TextView
    private lateinit var intensityText: TextView
    private lateinit var themeContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewOverlay = findViewById(R.id.previewOverlay)
        statusBadge = findViewById(R.id.statusBadge)
        themeNameText = findViewById(R.id.themeNameText)
        intensityText = findViewById(R.id.intensityText)
        themeContainer = findViewById(R.id.themeContainer)

        val masterSwitch = findViewById<MaterialSwitch>(R.id.masterSwitch)
        val boltsSwitch = findViewById<MaterialSwitch>(R.id.boltsSwitch)
        val speedlinesSwitch = findViewById<MaterialSwitch>(R.id.speedlinesSwitch)
        val auraSwitch = findViewById<MaterialSwitch>(R.id.auraSwitch)
        val intensitySeek = findViewById<SeekBar>(R.id.intensitySeek)
        val enableServiceBtn = findViewById<Button>(R.id.enableServiceBtn)
        val testBurstBtn = findViewById<Button>(R.id.testBurstBtn)

        masterSwitch.isChecked = VoltPrefs.isEnabled(this)
        boltsSwitch.isChecked = VoltPrefs.isBoltsEnabled(this)
        speedlinesSwitch.isChecked = VoltPrefs.isSpeedlinesEnabled(this)
        auraSwitch.isChecked = VoltPrefs.isAuraEnabled(this)

        val savedIntensity = VoltPrefs.getIntensity(this)
        intensitySeek.progress = savedIntensity - 20
        intensityText.text = "$savedIntensity%"

        masterSwitch.setOnCheckedChangeListener { _, checked -> VoltPrefs.setEnabled(this, checked) }
        boltsSwitch.setOnCheckedChangeListener { _, checked -> VoltPrefs.setBoltsEnabled(this, checked) }
        speedlinesSwitch.setOnCheckedChangeListener { _, checked -> VoltPrefs.setSpeedlinesEnabled(this, checked) }
        auraSwitch.setOnCheckedChangeListener { _, checked -> VoltPrefs.setAuraEnabled(this, checked) }

        intensitySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = progress + 20
                intensityText.text = "$value%"
                VoltPrefs.setIntensity(this@MainActivity, value)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        enableServiceBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        testBurstBtn.setOnClickListener {
            previewOverlay.triggerBurst(1.25f, 1)
        }

        buildThemeButtons()
        updateServiceStatus()
    }

    override fun onResume() {
        super.onResume()
        updateServiceStatus()
    }

    private fun buildThemeButtons() {
        themeContainer.removeAllViews()
        val currentIdx = VoltPrefs.getThemeIndex(this)
        themeNameText.text = VoltPrefs.THEMES[currentIdx].title

        VoltPrefs.THEMES.forEachIndexed { index, theme ->
            val btn = Button(this).apply {
                text = theme.title.split(" ").first()
                textSize = 11f
                isAllCaps = false
                setTextColor(if (index == currentIdx) 0xFF05070E.toInt() else 0xFFFFFFFF.toInt())
                setBackgroundColor(if (index == currentIdx) theme.primaryColor else 0xFF1E293B.toInt())
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(6, 0, 6, 0)
                layoutParams = lp
                setOnClickListener {
                    VoltPrefs.setThemeIndex(this@MainActivity, index)
                    buildThemeButtons()
                    previewOverlay.triggerBurst(1.1f, 1)
                }
            }
            themeContainer.addView(btn)
        }
    }

    private fun updateServiceStatus() {
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        val active = enabledServices.contains(packageName)
        statusBadge.text = if (active) {
            "ACTIVE — Open YouTube App & Scroll Shorts!"
        } else {
            "SETUP NEEDED — Tap 'Enable YouTube Overlay' below"
        }
        statusBadge.setTextColor(if (active) 0xFF34D399.toInt() else 0xFFFACC15.toInt())
    }
}
