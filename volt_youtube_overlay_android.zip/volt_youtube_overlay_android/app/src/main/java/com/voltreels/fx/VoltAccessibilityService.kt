package com.voltreels.fx

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.Build
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs

class VoltAccessibilityService : AccessibilityService() {

    private var windowManager: WindowManager? = null
    private var overlayView: LightningOverlayView? = null
    private var lastTriggerTime = 0L

    private val targetPackages = setOf(
        "com.google.android.youtube",
        "com.instagram.android"
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        attachOverlay()
    }

    private fun attachOverlay() {
        if (overlayView != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val view = LightningOverlayView(this)

        val overlayType = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        try {
            wm.addView(view, params)
            overlayView = view
        } catch (_: Exception) {
            overlayView = null
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !VoltPrefs.isEnabled(this)) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg !in targetPackages) return

        if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            val now = SystemClock.uptimeMillis()
            if (now - lastTriggerTime < 95L) return
            lastTriggerTime = now

            val deltaY = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) event.scrollDeltaY else 0
            val dir = if (deltaY < 0) -1 else 1
            val magnitude = abs(deltaY)
            val power = when {
                magnitude > 160 -> 1.25f
                magnitude > 60 -> 0.95f
                else -> 0.78f
            }

            overlayView?.post {
                overlayView?.triggerBurst(power, dir)
            }
        }
    }

    override fun onInterrupt() {
        // No-op
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            overlayView?.let { windowManager?.removeView(it) }
        } catch (_: Exception) {
        }
        overlayView = null
    }
}
