# VOLT FX Overlay — Native Android App (YouTube & Instagram)

Yeh ek **native Android Overlay App** hai jo directly **official YouTube app** (`com.google.android.youtube`) aur **Instagram app** (`com.instagram.android`) ke upar 60 FPS anime high-speed lightning bolts, manga speedlines aur glowing edge aura draw karta hai — bina aapke touch/scroll ko block kiye!

## APK Kaise Banaye (2 Easy Ways)

### Option 1: Bina PC ke (Sirf Phone se GitHub Actions par APK banao)
1. GitHub par ek free repository banao (e.g., `volt-fx-overlay`).
2. Is zip ke andar ke saare files/folders ko us repo mein upload karo.
3. GitHub repo ke **Actions** tab mein jao → **Build VOLT FX Android APK** workflow automatically run hoga (2 minute lagenge).
4. Run complete hone par **Artifacts → VOLT-FX-YouTube-Overlay-APK** download karo, unzip karke `app-debug.apk` apne Android phone mein install kar lo!

### Option 2: PC / Mac par (Android Studio)
1. Is zip ko extract karo aur **Android Studio** mein open karo.
2. Gradle sync hone do, phir **Build → Build Bundle(s) / APK(s) → Build APK(s)** dabao.
3. Generated `app-debug.apk` apne Android phone mein install karo.

## Phone Mein Setup (30 Seconds)
1. **VOLT FX Overlay** app open karo.
2. **Enable YouTube Overlay (Accessibility)** button dabao → Installed Apps / Downloaded Apps → **VOLT FX — YouTube & Reels Lightning** ko **ON** karo.
   *(Android 13+ par agar "Restricted setting" dikhe, toh Phone Settings → Apps → VOLT FX Overlay → top-right 3 dots → **Allow restricted settings** dabao, phir Accessibility ON karo.)*
3. Apna favourite Anime Style choose karo (Thunder Breathing, Godspeed Cyan, Hollow Purple, Crimson Flash, Cyber Overdrive).
4. Ab **official YouTube app** open karo, Shorts scroll karo — aur anime lightning enjoy karo!

> **Note for iPhone (iOS) users:** Apple iOS kisi bhi app ko doosre apps (jaise YouTube app) ke upar overlay draw karne ki permission nahi deta. iPhone par effect chalane ke liye Safari browser + Userscripts app use karo.
